import fang2.sprites._
import fang2.core.Game
import fang2.core.Sound
import java.awt.Color

class levelTwo(inputLives: Int) extends Game(700,700) {
  
  //Object Sprites
  val msgSprite: StringSprite = new StringSprite("Level 2")
  var back = new ImageSprite("BG.png")
  var user = new ImageSprite("player.png")
  var enemy = new ImageSprite("skull.png")
  var enemy2 = new ImageSprite("skull.png")
  var gameOver = new ImageSprite("gameOver.png")
  var wall1 = new ImageSprite("wall1.png")
  var wall2 = new ImageSprite("wall2.png")
  var wall12 = new ImageSprite("wall1.png")
  var gold = new ImageSprite("coin.png")
  var scoreSprite: StringSprite = new StringSprite("Lives: " + inputLives)
  var life = new ImageSprite("heart.png")
  //Game functionality sprites
  var timer: Double = 0
  var lives: Int = inputLives
  var playerSpeed = 0.03
  var startPlaying: Boolean = false
  var playing: Boolean = true
  //Sounds
  var collisionSound: Sound = new Sound("Bounce.wav")
  //var heartpickupSound: Sound = new Sound("")
  var killSound: Sound = new Sound("Death.wav")
  //var cheatCodeSound: Sound = new Sound(""
  var getGold: Sound = new Sound("gold_get.wav")


  override def setup {

    back.setScale(1.0)
    back.setLocation(0.5,0.5)
    addSprite(back)
    
    msgSprite.setScale(0.2)
    msgSprite.setLocation(0.5, 0.1)
    addSprite(msgSprite)

    gold.setScale(0.075)
    gold.setLocation(0.12,0.38)
    addSprite(gold)

    wall1.setScale(0.2)
    wall1.setLocation(0.3, 0.36)
    addSprite(wall1)
    
    wall12.setScale(0.2)
    wall12.setLocation(0.42, 0.36)
    addSprite(wall12)

    wall2.setScale(0.2)
    wall2.setLocation(0.125,0.5)
    addSprite(wall2)

    user.setScale(0.08)
    user.setLocation(0.5, 0.9)
    user.setColor(Color.black)
    addSprite(user)

    enemy.setScale(.15)
    enemy.setLocation(0.8,0.2)
    addSprite(enemy)
    
    enemy2.setScale(.12)
    enemy2.setLocation(0.04, 0.75)
    addSprite(enemy2)

    scoreSprite.setHeight(0.05)
    scoreSprite.setColor(Color.white)
    scoreSprite.topJustify()     // Location specifies top edge of string spr.
    scoreSprite.leftJustify()    // Location specifies left edge of sprite
    scoreSprite.setLocation(0,0) // Set location (upper left corner)
    scoreSprite.setScale(0.2)
    addSprite(scoreSprite)

    gameOver.setLocation(0.5,0.5)
    gameOver.setScale(1)
    addSprite(gameOver)
    gameOver.setVisible(false)

    playSoundImmediately()
    Sound.turnAllSoundOn()

  }

  private def normalize(coords: Array[Double]): Array[Double] = {
    val dist: Double = scala.math.sqrt(coords.map((v: Double)=>v*v).reduceLeft(_+_))
    coords.map((v: Double) => { -0.005 * v / dist })
    val dist2: Double = scala.math.sqrt(coords.map((v: Double)=>v*v).reduceLeft(_+_))
    coords.map((v: Double) => { -0.005 * v / dist2 })
  }

  override def advance (t: Double) {

    if (playing) {

      var dX = enemy.getX - user.getX
      var dY = enemy.getY - user.getY
      
      var dX2 = enemy2.getX - user.getX
      var dY2 = enemy2.getY - user.getY
     
      
      val dists: Array[Double] = normalize(Array(dX,dY))
      val dists2: Array[Double] = normalize(Array(dX2, dY2))

      if (user.getY < 0.85) {
        msgSprite.hide
        enemy.translate(dists(0),dists(1))
        enemy2.translate(dists2(0),dists2(1))
      } else {
        enemy.setLocation(enemy.getX, enemy.getY)
        enemy2.setLocation(enemy2.getX, enemy2.getY)
      }
      moveUser
      wallCollision
      enemyCollision
      collectGold


      def collectGold {
        if (user.intersects(gold)){
          getGold.play(1)
          gold.setVisible(false)
          addGame(new levelThree(lives))
          finishGame
        }
      }

      def wallCollision {
        if (user.intersects(wall1) || user.intersects(wall2) ||user.intersects(wall12)) {
          collisionSound.play(1.0)
          user.translateY(0.05)
          user.translateX(0.05)
          println("Hitting wall!")
        }
      }

      def enemyCollision {
        if (enemy.intersects(user) || enemy2.intersects(user)) {
          killSound.play(1)
          if (lives <= 0){
            println("No more lives...")
            gameOver.setVisible(true)
            playing = false
          } else {
            println("You Lost a Life!")
            updateLives(1)
            enemy.setLocation(0.8,0.2)
            enemy2.setLocation(0.04, 0.75) 
            user.setLocation(0.5, 0.9)
            playing = true
          }
        }
      }


      def moveUser {
        // Check the arrow keys for up movement
        if (upPressed) {
          // Move the sprite (up)
          user.translateY(-playerSpeed)
          // Block it from going above (back to the other side)
          if (user.getY < 0.0) {
            user.setY(0.0)
          }
        }
        // Check the arrow keys for down movement
        else if (downPressed) {
          // Move the sprite (down)
          user.translateY(playerSpeed)

          // Wrap the sprite if necessary
          if (user.getY > 1.0) {
            user.setY(1.0)
          }
        }
        // Check the arrow keys for up movement
        else if (leftPressed) {
          // Move the sprite (left)
          user.translateX(-playerSpeed)

          // Wrap the sprite if necessary
          if (user.getX < 0.0)
            user.setX(1.0)
        }
        // Check the arrow keys for up movement
        else if (rightPressed) {
          // Move the sprite (right)
          user.translateX(playerSpeed)

          // Wrap the sprite if necessary
          if (user.getX > 1.0)
            user.setX(0.0)
        }
      }

      def updateLives(amount: Int) {
        lives = lives - amount
        scoreSprite.setText("Lives: " + lives)
        //
      }
    } else {
      if (startPlaying) {
        timer += t
        if (timer > 0.5) {
          playing = true
          startPlaying = false
        }
      }
    }
  }
}

