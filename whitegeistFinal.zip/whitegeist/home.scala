import fang2.sprites._
import fang2.core.Game
import fang2.core.Sound
import java.awt.Color
import fang2.media.MidiSound


class home extends Game(700,700) {

  //Object Sprites
  val myStartGame = new ImageSprite("titlescreen.png")
  var back = new ImageSprite("BG.png")
  var cheat: OvalSprite = new OvalSprite(1,1)
  var user = new ImageSprite("player.png")
  var enemy = new ImageSprite("skull.png")
  var gameOver = new ImageSprite("gameOver.png")
  var wall1 = new ImageSprite("wall1.png")
  var wall2 = new ImageSprite("wall2.png")
  var gold = new ImageSprite("coin.png")
  var scoreSprite: StringSprite = new StringSprite("Lives: 3")
  var life = new ImageSprite("heart.png")
  //Game functionality sprites
  var timer: Double = 0
  var lives: Int = 3
  var playerSpeed = 0.03
  var startPlaying: Boolean = true
  var playing: Boolean = false
  //Sounds
  var collisionSound: Sound = new Sound("Bounce.wav")
  //var heartpickupSound: Sound = new Sound("")
  var killSound: Sound = new Sound("Death.wav")
  var cheatcodeSound: Sound = new Sound("Dirty_Cheater.wav")
  var getGold: Sound = new Sound("gold_get.wav")


  override def setup {

    back.setScale(1.0)
    back.setLocation(0.5,0.5)
    addSprite(back)

    gold.setScale(0.088)
    gold.setLocation(0.22,0.32)
    addSprite(gold)

    wall1.setScale(0.2)
    wall1.setLocation(0.3, 0.29)
    addSprite(wall1)

    wall2.setScale(0.2)
    wall2.setLocation(0.225,0.39)
    addSprite(wall2)

    user.setScale(0.08)
    user.setLocation(0.5, 0.9)
    user.setColor(Color.black)
    addSprite(user)
    
    cheat.setScale(0.01)
    cheat.setLocation(0.1,0.9)
    cheat.setColor(Color.white)
    addSprite(cheat)

    enemy.setScale(.13)
    enemy.setLocation(0.8,0.2)
    addSprite(enemy)

    scoreSprite.setHeight(0.05)
    scoreSprite.setColor(Color.white)
    scoreSprite.topJustify()     // Location specifies top edge of string spr.
    scoreSprite.leftJustify()    // Location specifies left edge of sprite
    scoreSprite.setLocation(0,0) // Set location (upper left corner)
    scoreSprite.setScale(0.2)
    addSprite(scoreSprite)

    myStartGame.setLocation(0.5,0.5)
    myStartGame.setScale(1)
    addSprite(myStartGame)

    gameOver.setLocation(0.5,0.5)
    gameOver.setScale(1)
    addSprite(gameOver)
    gameOver.setVisible(false)

    playSoundImmediately()
    Sound.turnAllSoundOn()
    
    setHelpText("Use the arrow keys to move yourself around---Once you enter the graveyard the spooky skull will chase you. Collect the coin to advance to the next Level until you reach the boss on Level 4...He will attack you wherever you are. FOR PROF. BLAKE ---> run into the white dot on level 1 to cheat to the boss")

  }

  private def normalize(coords: Array[Double]): Array[Double] = {
    val dist: Double = scala.math.sqrt(coords.map((v: Double)=>v*v).reduceLeft(_+_))
    coords.map((v: Double) => { -0.005 * v / dist })
  }

  override def advance (t: Double) {

    if (playing) {
      
      var dX = enemy.getX - user.getX
      var dY = enemy.getY - user.getY
      val dists: Array[Double] = normalize(Array(dX,dY))

      if (user.getY < 0.85) {
        enemy.translate(dists(0),dists(1))
      } else {
        enemy.setLocation(enemy.getX, enemy.getY)
      }
      
      moveUser
      wallCollision
      enemyCollision
      collectGold
      cheater


      def collectGold {
        if (user.intersects(gold)){
          getGold.play(1)
          gold.setVisible(false)
          addGame(new levelTwo(lives))
          finishGame
        }
      }
      
      def cheater {
        if (user.intersects(cheat)) {
          cheatcodeSound.play(1)
          println("DIRTY CHEATER!")
          cheat.setVisible(false)
          addGame(new Boss(lives))
          finishGame
        }
      }

      def wallCollision {
        if (user.intersects(wall1) || user.intersects(wall2)){
          collisionSound.play(1.0)
          user.translateY(0.05)
          user.translateX(0.05)
          println("Hitting wall!")
        }
      }

      def enemyCollision {
        if (enemy.intersects(user)){
          killSound.play(1)
          if (lives < 0){
            println("No more lives...")
            gameOver.setVisible(true)
          } else {
            println("You Lost a Life!")
            updateLives(1)
            enemy.setLocation(0.8,0.2)
            user.setLocation(0.5, 0.9)
            playing = true
          }
        }
      }

      def moveUser {
        // Check the arrow keys for up movement
        if (upPressed) {
          // Move the sprite (up)
          user.translateY(-playerSpeed)
          // Block it from going above (back to the other side)
          if (user.getY < 0.0) {
            user.setY(0.0)
          }
        }
        // Check the arrow keys for down movement
        else if (downPressed) {
          // Move the sprite (down)
          user.translateY(playerSpeed)

          // Wrap the sprite if necessary
          if (user.getY > 1.0) {
            user.setY(1.0)
          }
        }
        // Check the arrow keys for up movement
        else if (leftPressed) {
          // Move the sprite (left)
          user.translateX(-playerSpeed)

          // Wrap the sprite if necessary
          if (user.getX < 0.0)
            user.setX(1.0)
        }
        // Check the arrow keys for up movement
        else if (rightPressed) {
          // Move the sprite (right)
          user.translateX(playerSpeed)

          // Wrap the sprite if necessary
          if (user.getX > 1.0)
            user.setX(0.0)
        }
      }

      def updateLives(amount: Int) {
        lives = lives - amount
        scoreSprite.setText("Lives: " + lives)
        //
      }
    } else {
      if (startPlaying) {
        timer += t
        if (timer > 0.5) {
          myStartGame.setVisible(false)
          playing = true
          startPlaying = false
        }
      }
    }
  }
}

